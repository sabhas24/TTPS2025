export interface UsuarioToken {
    id: number;
    nombre: string;
    apellido: string;
    email: string;
    barrio: string;
    ciudad: string;
}
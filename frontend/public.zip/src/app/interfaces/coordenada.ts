export interface Coordenada {
    latitud: number;
    longitud: number;
    barrio: string;
}
